
import { prisma } from '../src/lib/prisma';
import { Role } from '../src/generated/prisma/client';

async function main() {
    console.log('Starting Admin Dashboard Verification...');

    // 1. Create a Dummy Admin User (if not exists)
    // We need to ensure there is at least one admin to test "admin-like" DB queries
    let admin = await prisma.user.findFirst({ where: { role: 'ADMIN' } });

    if (!admin) {
        console.log('Creating dummy ADMIN user...');
        admin = await prisma.user.create({
            data: {
                name: 'Admin User',
                email: `admin-${Date.now()}@example.com`,
                role: 'ADMIN',
            }
        });
    }
    console.log(`Admin User: ${admin.email}`);

    // 2. Create a User to Delete
    const userToDelete = await prisma.user.create({
        data: {
            name: 'To Be Deleted',
            email: `delete-me-${Date.now()}@example.com`,
            role: 'USER',
        }
    });
    console.log(`User created for deletion: ${userToDelete.email}`);

    // 3. Simulate Stats Fetching (Direct DB count)
    console.log('Fetching Stats...');
    const userCount = await prisma.user.count({ where: { role: 'USER' } });
    const guideCount = await prisma.user.count({ where: { role: 'GUIDE' } });
    const appointmentCount = await prisma.appointment.count();
    const messageCount = await prisma.message.count();

    console.log('Stats:', { userCount, guideCount, appointmentCount, messageCount });

    if (userCount >= 0 && guideCount >= 0) {
        console.log('Stats fetching logic is valid.');
    }

    // 4. Simulate User Deletion
    console.log(`Deleting user ${userToDelete.id}...`);
    await prisma.user.delete({
        where: { id: userToDelete.id },
    });

    const checkUser = await prisma.user.findUnique({ where: { id: userToDelete.id } });
    if (!checkUser) {
        console.log('Verification Successful: User deleted.');
    } else {
        console.error('Verification Failed: User still exists.');
        process.exit(1);
    }
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
