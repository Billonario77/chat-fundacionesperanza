
import { prisma } from '../src/lib/prisma';

async function main() {
    console.log('Starting Video Call Verification...');

    // 1. Fetch Users
    const seeker = await prisma.user.findFirst({ where: { role: 'USER' } });
    const guide = await prisma.user.findFirst({ where: { role: 'GUIDE' } });

    if (!seeker || !guide) {
        console.error('Users not found.');
        process.exit(1);
    }

    console.log(`Seeker: ${seeker.email}`);
    console.log(`Guide: ${guide.email}`);

    // 2. Simulate Booking with Meeting Link Generation
    // We can't easily call the server action here because it depends on `auth()`,
    // but we can simulate the DB insertion logic that the action performs
    // AND verify that our previous manual DB insertions (if any) or future ones respect the schema.

    // Actually, we want to see if `crypto.randomUUID()` works in the environment.
    // We can't test that here fully since this script runs in standard Node, not Next.js runtime,
    // but the syntax is standard.

    const meetingLink = `https://meet.jit.si/antigravity-verification-${Date.now()}`;

    console.log('Simulating Appointment Creation with Video Link...');

    const appointment = await prisma.appointment.create({
        data: {
            seekerId: seeker.id,
            guideId: guide.id,
            startTime: new Date(Date.now() + 86400000), // Tomorrow
            endTime: new Date(Date.now() + 86400000 + 3600000),
            status: 'CONFIRMED', // Directly confirmed to test "Join" button logic eligibility in UI (conceptually)
            notes: 'Video Call Test',
            meetingLink,
        }
    });

    console.log('Appointment created:', appointment.id);
    console.log('Meeting Link:', appointment.meetingLink);

    if (appointment.meetingLink && appointment.meetingLink.includes('meet.jit.si')) {
        console.log('Verification Successful: Meeting link stored correctly.');
    } else {
        console.error('Verification Failed: Meeting link missing or invalid.');
        process.exit(1);
    }
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
