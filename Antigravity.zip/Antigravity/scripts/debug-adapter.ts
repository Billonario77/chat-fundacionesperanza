
import * as adapter from '@prisma/adapter-libsql';
console.log('Adapter exports:', adapter);
