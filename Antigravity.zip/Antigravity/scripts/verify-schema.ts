
import 'dotenv/config';
console.log('ENV DB URL:', process.env.DATABASE_URL);
import { prisma } from '../src/lib/prisma';

async function main() {
    console.log('Starting verification...');

    // 1. Create a User (Seeker)
    const seeker = await prisma.user.create({
        data: {
            email: `seeker-${Date.now()}@example.com`,
            name: 'Test Seeker',
            role: 'USER',
            profile: {
                create: {
                    bio: 'I am a seeker looking for guidance.',
                    isAvailable: false,
                },
            },
        },
        include: { profile: true },
    });
    console.log('Created Seeker:', seeker.email);

    // 2. Create a User (Guide)
    const guide = await prisma.user.create({
        data: {
            email: `guide-${Date.now()}@example.com`,
            name: 'Test Guide',
            role: 'GUIDE',
            profile: {
                create: {
                    bio: 'I am a experienced spiritual guide.',
                    specialties: 'Meditation,Yoga',
                    isAvailable: true,
                },
            },
        },
        include: { profile: true },
    });
    console.log('Created Guide:', guide.email);

    // 3. Create an Appointment
    const appointment = await prisma.appointment.create({
        data: {
            seekerId: seeker.id,
            guideId: guide.id,
            startTime: new Date(),
            endTime: new Date(Date.now() + 3600000), // 1 hour later
            status: 'PENDING',
            notes: 'Initial consultation',
        },
    });
    console.log('Created Appointment:', appointment.id);

    // 4. Create a Journal Entry
    const journal = await prisma.journalEntry.create({
        data: {
            userId: seeker.id,
            title: 'My First Entry',
            content: 'Today I feel hopeful.',
            mood: 'Hopeful',
            privacy: 'PRIVATE',
        },
    });
    console.log('Created Journal Entry:', journal.id);

    // 5. Create a Notification
    const notification = await prisma.notification.create({
        data: {
            userId: guide.id,
            type: 'APPOINTMENT',
            message: 'You have a new appointment request.',
        },
    });
    console.log('Created Notification:', notification.id);

    // 6. Verify Relations
    const seekerWithRelations = await prisma.user.findUnique({
        where: { id: seeker.id },
        include: {
            appointmentsAsSeeker: true,
            journalEntries: true,
            profile: true,
        },
    });

    if (!seekerWithRelations?.appointmentsAsSeeker.length) throw new Error('Seeker appointments relation failed');
    if (!seekerWithRelations?.journalEntries.length) throw new Error('Seeker journal relation failed');
    if (!seekerWithRelations?.profile) throw new Error('Seeker profile relation failed');

    console.log('Verification Successful!');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
